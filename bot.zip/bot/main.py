import discord
from discord.ext import commands
import random, string

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_member_join(member):
    name = ''.join(random.choices(string.ascii_lowercase + string.digits, k=5))
    overwrites = {
        member.guild.default_role: discord.PermissionOverwrite(view_channel=False),
        member: discord.PermissionOverwrite(view_channel=True, send_messages=True)
    }
    channel = await member.guild.create_text_channel(name=f'user-{name}', overwrites=overwrites)
    msg = await channel.send(f"أهلاً بك في رومتك السرية.\nآيدي الروم: `{channel.id}`")
    await msg.pin()

@bot.command()
@commands.has_permissions(administrator=True)
async def D(ctx, channel_id: int, *, message):
    channel = bot.get_channel(channel_id)
    if channel:
        await channel.send(f"**[إدارة]:** {message}")
        await ctx.send("تم الإرسال!")

bot.run('MTQ3MjM3MDY5OTk4MDI0Mjk0NA.GfGWNn.XO5k9njg91I57IVvRHNmMKfKg-gp4KNFlt8N_s')
